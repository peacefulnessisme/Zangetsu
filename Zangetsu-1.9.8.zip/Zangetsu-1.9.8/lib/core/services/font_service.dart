import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SubtitleFontManager {
  static const String _fontPathKey = 'custom_subtitle_font_path';
  static const String customFontFamily = 'CustomSubtitleFont';

  // اختيار ملف الخط وحفظه محلياً
  static Future<bool> importCustomFont() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['ttf', 'otf'],
    );

    if (result != null && result.files.single.path != null) {
      File pickedFile = File(result.files.single.path!);
      final appDir = await getApplicationDocumentsDirectory();
      final fileName = pickedFile.path.split('/').last;
      final savedFont = await pickedFile.copy('${appDir.path}/$fileName');

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_fontPathKey, savedFont.path);

      await loadCustomFont();
      return true;
    }
    return false;
  }

  // تحميل الخط في الذاكرة
  static Future<void> loadCustomFont() async {
    final prefs = await SharedPreferences.getInstance();
    final fontPath = prefs.getString(_fontPathKey);

    if (fontPath != null && File(fontPath).existsSync()) {
      final fontFile = File(fontPath);
      final bytes = await fontFile.readAsBytes();
      
      final fontLoader = FontLoader(customFontFamily);
      fontLoader.addFont(Future.value(ByteData.view(bytes.buffer)));
      await fontLoader.load();
    }
  }

  // التحقق من وجود الخط
  static Future<bool> hasCustomFont() async {
    final prefs = await SharedPreferences.getInstance();
    final fontPath = prefs.getString(_fontPathKey);
    return fontPath != null && File(fontPath).existsSync();
  }
}
